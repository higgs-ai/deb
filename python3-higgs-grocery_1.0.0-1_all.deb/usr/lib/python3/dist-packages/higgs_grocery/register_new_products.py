
# python interpreter searchs these subdirectories for modules
from email.mime import application
import sys
sys.path.insert(0, './yolov5')
sys.path.insert(0, './sort')

from tkinter import Entry,Label,StringVar,RAISED
import threading
import argparse
import os
import platform
import shutil
import time
from pathlib import Path
import cv2
import torch
import torch.backends.cudnn as cudnn
from yolov5.product_database.productsmanager import ProductManager
#yolov5
from yolov5.utils.datasets import LoadImages, LoadStreams
from yolov5.utils.general import check_img_size, non_max_suppression, scale_coords
from yolov5.utils.torch_utils import select_device, time_synchronized
import tkinter
import PIL.Image, PIL.ImageTk
from tkinter import messagebox
from tkinter import simpledialog
#SORT
import skimage
from sort import *

torch.set_printoptions(precision=3)

palette = (2 ** 11 - 1, 2 ** 15 - 1, 2 ** 20 - 1)


list_of_registered=[]
continue_imageing=False
pro_manager = ProductManager()
roi_image_list = []
latch=False
done=False
capt=False
final=False
window = tkinter.Tk()
en=None
cap_count=0

def register_product(roi_image,identity,application_window):
    global roi_image_list,latch,done,capt,final,window,en,var2,varlabel2,cap_count

    
    
    if capt==True:
        
        latch=True
        capt=False

    if final==True:
        latch=False
        done=True
        final=False
        
    if latch:
        cap_count=cap_count+1
        roi_image_list.append(roi_image)
        st="Captured :" + str(cap_count) + " image(s)"
        varlabel2.set(st)
        latch=False
        return

    if done:
            
        cv2.waitKey(30)
        
            
        answer = en.get() 
        value= str(answer)
        str_array = value.split(",")

        sku = str_array[0]
        name = str_array[1]
        size = str_array[2]
        pro_manager.add_new_product(sku,name,size,roi_image_list)
        list_of_registered.append(identity)
        st = "Registered " + name + " successfully!"
        messagebox.showinfo("Product Saved",st)
        print("registered identity: " + str(identity))
        cap_count=0
        roi_image_list=[]
        done=False
        var2.set("")
        varlabel2.set("")
        return
                












  







def manage_tracks(tracked_dets, image):
    global window
    application_window=window
    if  len(tracked_dets) > 0:

        for j, tracked_dets in enumerate(tracked_dets):
            bbox_x1 = tracked_dets[0]
            bbox_y1 = tracked_dets[1]
            bbox_x2 = tracked_dets[2]
            bbox_y2 = tracked_dets[3]
            category = tracked_dets[4]
            u_overdot = tracked_dets[5]
            v_overdot = tracked_dets[6]
            s_overdot = tracked_dets[7]
            identity = tracked_dets[8]
            
            ROI = image[int(bbox_y1):int(bbox_y2), int(bbox_x1):int(bbox_x2)]
            register_product(ROI,identity,application_window)
            identity = tracked_dets[8]
            
        


def bbox_rel(*xyxy):
    """" Calculates the relative bounding box from absolute pixel values. """
    bbox_left = min([xyxy[0].item(), xyxy[2].item()])
    bbox_top = min([xyxy[1].item(), xyxy[3].item()])
    bbox_w = abs(xyxy[0].item() - xyxy[2].item())
    bbox_h = abs(xyxy[1].item() - xyxy[3].item())
    x_c = (bbox_left + bbox_w / 2)
    y_c = (bbox_top + bbox_h / 2)
    w = bbox_w
    h = bbox_h
    return x_c, y_c, w, h


def compute_color_for_labels(label):
    """
    Simple function that adds fixed color depending on the class
    """
    color = [int((p * (label ** 2 - label + 1)) % 255) for p in palette]
    return tuple(color)






def draw_boxes(img, bbox, identities=None, categories=None, names=None, velocity=None,offset=(0, 0)):
    for i, box in enumerate(bbox):
        x1, y1, x2, y2 = [int(i) for i in box]
        x1 += offset[0]
        x2 += offset[0]
        y1 += offset[1]
        y2 += offset[1]
        vel = velocity[i]
        
        # box text and bar
        cat = int(categories[i]) if categories is not None else 0
        
        id = int(identities[i]) if identities is not None else 0
        
        color = compute_color_for_labels(id)
        
        label = f'{names[cat]} | {id}'
        t_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_PLAIN, 2, 2)[0]
        cv2.rectangle(img, (x1, y1), (x2, y2), color, 3)
        cv2.rectangle(
            img, (x1, y1), (x1 + t_size[0] + 3, y1 + t_size[1] + 4), color, -1)
        cv2.putText(img, label, (x1, y1 +
                                 t_size[1] + 4), cv2.FONT_HERSHEY_PLAIN, 2, [255, 255, 255], 2)
        cv2.putText(img, str(int(vel*100)), (x1, y1 +
                                 t_size[1] + 20), cv2.FONT_HERSHEY_PLAIN, 1, [255, 255, 255], 2)
    return img




parser = argparse.ArgumentParser()
parser.add_argument('--weights', type=str,
                        default='yolov5/weights/yolov5s.pt', help='model.pt path')
# file/folder, 0 for webcam
parser.add_argument('--source', type=str,
                        default='inference/images', help='source')
parser.add_argument('--output', type=str, default='inference/output',
                        help='output folder')  # output folder
parser.add_argument('--img-size', type=int, default=320,
                        help='inference size (pixels)')
parser.add_argument('--conf-thres', type=float,
                        default=0.1, help='object confidence threshold')
parser.add_argument('--iou-thres', type=float,
                        default=0.3, help='IOU threshold for NMS')
parser.add_argument('--fourcc', type=str, default='mp4v',
                        help='output video codec (verify ffmpeg support)')
parser.add_argument('--device', default='',
                        help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
parser.add_argument('--view-img', action='store_true',
                        help='display results')
parser.add_argument('--save-img', action='store_true',
                        help='save video file to output folder (disable for speed)')
parser.add_argument('--save-txt', action='store_true',
                        help='save results to *.txt')
parser.add_argument('--classes', nargs='+', type=int,
                        default=[i for i in range(80)], help='filter by class') #80 classes in COCO dataset
parser.add_argument('--agnostic-nms', action='store_true',
                        help='class-agnostic NMS')
parser.add_argument('--augment', action='store_true',
                        help='augmented inference')
    
#SORT params
parser.add_argument('--sort-max-age', type=int, default=220,
                        help='keep track of object even if object is occluded or not detected in n frames')
parser.add_argument('--sort-min-hits', type=int, default=2,
                        help='start tracking only after n number of objects detected')
parser.add_argument('--sort-iou-thresh', type=float, default=0.2,
                        help='intersection-over-union threshold between two frames for association')
    
args = parser.parse_args()
args.img_size = check_img_size(args.img_size)
opt = args
def detect():
    global opt
    with torch.no_grad():
        
        out, source, weights, view_img, save_txt, imgsz, save_img, sort_max_age, sort_min_hits, sort_iou_thresh= \
            opt.output, opt.source, opt.weights, opt.view_img, opt.save_txt, opt.img_size, opt.save_img, opt.sort_max_age, opt.sort_min_hits, opt.sort_iou_thresh
        
        webcam = source == '0' or source.startswith(
            'rtsp') or source.startswith('http') or source.endswith('.txt')
        # Initialize SORT
        sort_tracker = Sort(max_age=sort_max_age,
                        min_hits=sort_min_hits,
                        iou_threshold=sort_iou_thresh) # {plug into parser}
        
        
        # Directory and CUDA settings for yolov5
        device = select_device(opt.device)
        if os.path.exists(out):
            shutil.rmtree(out)  # delete output folder
        os.makedirs(out)  # make new output folder
        half = device.type != 'cpu'  # half precision only supported on CUDA

        # Load yolov5 model
        model = torch.load(weights, map_location=device)['model'].float() #load to FP32. yolov5s.pt file is a dictionary, so we retrieve the model by indexing its key
        model.to(device).eval()
        if half:
            model.half() #to FP16

        # Set DataLoader
        vid_path, vid_writer = None, None
        
        if webcam:
            view_img = True
            cudnn.benchmark = True  # set True to speed up constant image size inference
            dataset = LoadStreams(source, img_size=imgsz)
        else:
            dataset = LoadImages(source, img_size=imgsz)
        
        # get names of object categories from yolov5.pt model
        names = model.module.names if hasattr(model, 'module') else model.names 
        
        # Run inference
        t0 = time.time()
        img = torch.zeros((1,3,imgsz,imgsz), device=device) #init img
        
        # Run once (throwaway)
        _ = model(img.half() if half else img) if device.type != 'cpu' else None
        
        save_path = str(Path(out))
        txt_path = str(Path(out))+'/results.txt'
        
        for frame_idx, (path, img, im0s, vid_cap) in enumerate(dataset): #for every frame
            img= torch.from_numpy(img).to(device)
            img = img.half() if half else img.float() #unint8 to fp16 or fp32
            img /= 255.0 #normalize to between 0 and 1.
            if img.ndimension()==3:
                img = img.unsqueeze(0)
                
            # Inference
            t1 = time_synchronized()
            pred = model(img, augment=opt.augment)[0] 

            # Apply NMS
            pred = non_max_suppression(
                pred, opt.conf_thres, opt.iou_thres, classes=opt.classes, agnostic=opt.agnostic_nms)
            t2 = time_synchronized()
            
            # Process detections
            for i, det in enumerate(pred): #for each detection in this frame
                if webcam:  # batch_size >= 1
                    p, s, im0 = path[i], '%g: ' % i, im0s[i].copy()
                else:
                    p, s, im0 = path, '', im0s
                
                s += f'{img.shape[2:]}' #print image size and detection report
                save_path = str(Path(out) / Path(p).name)

                # Rescale boxes from img_size (temporarily downscaled size) to im0 (native) size
                det[:, :4] = scale_coords(
                    img.shape[2:], det[:, :4], im0.shape).round()
                
                for c in det[:, -1].unique(): #for each unique object category
                    n = (det[:, -1] ==c).sum() #number of detections per class
                    s += f' - {n} {names[int(c)]}'

                dets_to_sort = np.empty((0,6))

                # Pass detections to SORT
                # NOTE: We send in detected object class too
                for x1,y1,x2,y2,conf,detclass in det.cpu().detach().numpy():
                    dets_to_sort = np.vstack((dets_to_sort, np.array([x1, y1, x2, y2, conf, detclass])))
            

                # Run SORT
                tracked_dets = sort_tracker.update(dets_to_sort)

            

                
                # draw boxes for visualization
                if len(tracked_dets)>0:
                    bbox_xyxy = tracked_dets[:,:4]
                    identities = tracked_dets[:, 8]
                    categories = tracked_dets[:, 4]
                    u_overdot = tracked_dets[:,5]
                    draw_boxes(im0, bbox_xyxy, identities, categories, names,u_overdot)
                    manage_tracks(tracked_dets, im0)

                    
                # Write detections to file. NOTE: Not MOT-compliant format.
                if save_txt and len(tracked_dets) != 0:
                    for j, tracked_dets in enumerate(tracked_dets):
                        bbox_x1 = tracked_dets[0]
                        bbox_y1 = tracked_dets[1]
                        bbox_x2 = tracked_dets[2]
                        bbox_y2 = tracked_dets[3]
                        category = tracked_dets[4]
                        u_overdot = tracked_dets[5]
                        v_overdot = tracked_dets[6]
                        s_overdot = tracked_dets[7]
                        identity = tracked_dets[8]
                        
                        with open(txt_path, 'a') as f:
                            f.write(f'{frame_idx},{bbox_x1},{bbox_y1},{bbox_x2},{bbox_y2},{category},{u_overdot},{v_overdot},{s_overdot},{identity}\n')
                    
                
                # Stream image results(opencv)
                if view_img:
                    cv2.imshow(p,im0)
                    if cv2.waitKey(1)==ord('q'): #q to quit
                        cv2.destroyAllWindows()
                        raise StopIteration
                # Save video results
                if save_img:
                    
                    if dataset.mode == 'images':
                        cv2.imwrite(save_path, im0)
                    else:
                        
                        if vid_path != save_path:  # new video
                            vid_path = save_path
                            if isinstance(vid_writer, cv2.VideoWriter):
                                vid_writer.release()  # release previous video writer

                            fps = vid_cap.get(cv2.CAP_PROP_FPS)
                            w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                            h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                            vid_writer = cv2.VideoWriter(
                                save_path, cv2.VideoWriter_fourcc(*opt.fourcc), fps, (w, h))
                        vid_writer.write(im0)
        if save_txt or save_img:
            print('Results saved to %s' % os.getcwd() + os.sep + out)
            if platform == 'darwin':  # MacOS
                os.system('open ' + save_path)

        print('Done. (%.3fs)' % (time.time() - t0))

var = StringVar()
var2 = StringVar()
varlabel2 =  StringVar()
def capture():


    global capt
    capt=True

def finalise():

    global final
    final=True
    


def start_app():
    threading.Thread(target=detect).start()

    
if __name__ == '__main__':

    
    

    #UI code, ToDo: Convert to oops later!

    
    window.geometry("500x700")

    window.title("Product Registration")

    with torch.no_grad():
        
        B = tkinter.Button(window, text ="Start Camera", command=start_app)
        B.pack()
        B.place(x=170, y=100)


        Cap = tkinter.Button(window, text ="Capture", command = capture)
        Cap.pack()
        Cap.place(x=200, y=200)

        ff = tkinter.Button(window, text ="Finalise", command = finalise)
        ff.pack()
        ff.place(x=200, y=500)
        
        label = Label( window, textvariable=var, relief=RAISED )
        var.set("Enter sku,name,size before finalise::")
        label.pack()
        label.place(x=0, y=300)


        label2 = Label( window, textvariable=varlabel2)
        varlabel2.set("")
        label2.pack()
        label2.place(x=350, y=200)


        var2.set("")
        en = Entry(window, textvariable=var2)
        en.pack()
        en.place(x=300, y=300)
        en.focus_set()


        window.mainloop()
             
    
        
